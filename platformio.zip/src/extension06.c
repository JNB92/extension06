/** EX: E6.0

TASK:

Your task is to write code which handles a sequence of input characters
from the UART interface, and respond with the output specified below.

On receipt of the character sequence:

- "foo" your programme should print '0' to the UART interface.
- "bar" your programme should print '1' to the UART interface.
- "foobar" your program should not print either '0' nor '1' as
  specified above, but should instead print a linefeed ('\n')
  character.

NOTE:

It is strongly recommended that you design a state machine to complete
this task, and practice drawing a state machine diagram before you
begin coding.

Your solution should use a baud rate of 9600, and 8N1 frame format.
Your solution MUST NOT use qutyio.o or qutyserial.o.

EXAMPLES:

INPUT: ...foo.bar.foo.barfoobarfood
OUTPUT: 0101\n0

0101
0(END)

INPUT: barsfoosbarforbarfoobarrforfoobarfoobarfood
OUTPUT: 1011\n\n\n0

1011


0(END)

*/

#include <stdio.h>
#include <stdint.h>
#include <avr/io.h>


#define BAUD_RATE 9600 // Baud rate in bits per second
#define FRAME_FORMAT 3.33  // 8N1

// Function prototypes
typedef enum {
    STATE_INITIAL,
    STATE_F,
    STATE_FO,
    STATE_FOO,
    STATE_B,
    STATE_BA,
    STATE_BAR,
    STATE_FOOF,
    STATE_FOOFO,
    STATE_FOOFOO
} State;

State currentState = STATE_INITIAL; // Initial state


void UART_init() {
    
    uint16_t UBRR_val = (F_CPU/16/BAUD_RATE) - 1; // Calculate baud rate register value

   
    USART0.BAUD = (uint16_t)UBRR_val; // Set baud rate register value


    USART0.CTRLB = USART_RXEN_bm | USART_TXEN_bm; // Enable UART receiver and transmitter


    USART0.CTRLC = USART_CHSIZE_8BIT_gc; // Set frame format to 8N1
}


char UART_receive() {
    while (!(USART0.STATUS & USART_RXCIF_bm));  // Wait until data received
    return USART0.RXDATAL;
}


void UART_transmit(char data) {
    while (!(USART0.STATUS & USART_DREIF_bm));  // Wait until data register empty
    USART0.TXDATAL = data;
}

int main(void) {
   
    UART_init(); // Initialise UART

    char inputChar;

    while (1) {
        inputChar = UART_receive();  // Receive input character

        switch (currentState) {
            case STATE_INITIAL:
                if (inputChar == 'f') {
                    currentState = STATE_F;
                } else if (inputChar == 'b') {
                    currentState = STATE_B;
                }
                break;

            case STATE_F:
                if (inputChar == 'o') {
                    currentState = STATE_FO;
                } else {
                    currentState = STATE_INITIAL;
                }
                break;

            case STATE_FO:
                if (inputChar == 'o') {
                    currentState = STATE_FOO;
                } else if (inputChar == 'f') {
                    currentState = STATE_FOOF;
                } else {
                    currentState = STATE_INITIAL;
                }
                break;

            case STATE_FOO:
                if (inputChar == 'f') {
                    currentState = STATE_FOOF;
                } else if (inputChar == 'b') {
                    UART_transmit('0');
                    currentState = STATE_B;
                } else {
                    currentState = STATE_INITIAL;
                }
                break;

            case STATE_B:
                if (inputChar == 'a') {
                    currentState = STATE_BA;
                } else {
                    currentState = STATE_INITIAL;
                }
                break;

            case STATE_BA:
                if (inputChar == 'r') {
                    currentState = STATE_BAR;
                } else {
                    currentState = STATE_INITIAL;
                }
                break;

            case STATE_BAR:
                UART_transmit('1');
                currentState = STATE_INITIAL;
                break;

            case STATE_FOOF:
                if (inputChar == 'o') {
                    currentState = STATE_FOOFO;
                } else {
                    currentState = STATE_INITIAL;
                }
                break;

            case STATE_FOOFO:
                if (inputChar == 'o') {
                    currentState = STATE_FOOFOO;
                } else {
                    currentState = STATE_INITIAL;
                }
                break;

            case STATE_FOOFOO:
                UART_transmit('\n');
                currentState = STATE_INITIAL;
                break;
        }
    }

    return 0;
}


/** CODE: Write your code for Ex E6.0 above this line. */
